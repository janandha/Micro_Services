package com.line.chart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LineChartApplicationTests {

	@Test
	void contextLoads() {
	}

}
