package com.line.chart.Controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.line.chart.model.Data;
import com.line.chart.services.FileService;

@RestController
public class LineChartController {
	
	@Autowired
	private FileService fileService;


	@GetMapping("/values")
	public List<Data> datas(){
		
		List<Data> ls=new ArrayList<>();
		LocalDate today = LocalDate.now();     
       
		ls.add(new Data(5,today.format(DateTimeFormatter.ofPattern("yyyy,MM,dd"))));
		ls.add(new Data(1,today.minusDays(1).format(DateTimeFormatter.ofPattern("yyyy,MM,dd"))));
		ls.add(new Data(2,today.minusDays(2).format(DateTimeFormatter.ofPattern("yyyy,MM,dd"))));
		ls.add(new Data(4,today.minusDays(3).format(DateTimeFormatter.ofPattern("yyyy,MM,dd"))));
		ls.add(new Data(1,today.minusDays(4).format(DateTimeFormatter.ofPattern("yyyy,MM,dd"))));
		
		
		return ls;
		
	}
	
	
	
//	@PostMapping("/")
//    public String uploadMultipartFile(@RequestParam("uploadfile") MultipartFile file) {
//		System.out.println("Hi Hello");
//		return null;
//    }
	
}
