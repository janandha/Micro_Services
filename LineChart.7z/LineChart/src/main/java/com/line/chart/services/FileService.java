package com.line.chart.services;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.line.chart.model.Data;
import com.line.chart.model.jsonObject;
import com.line.chart.model.stageObject;

@Service
public class FileService {
	
	Map<LocalDate,Integer> dateCount=new HashMap<>();
	Map<String,Integer> stageCount=new HashMap<>();
	Map<String,Integer> metricsCount=new HashMap<>();
	//Map<LocalDate,Integer> dateCount=new HashMap<>();
	
	public void process(MultipartFile file) {
		//Resource resource = new ClassPathResource("classpath:requestqueue-report-16995604654768647471.xlsx");
		//Map<LocalDate,Integer> dateCount=new HashMap<>();
		
		dateCount.clear();
		stageCount.clear();
		try {
			Workbook workbook = new XSSFWorkbook(file.getInputStream());
			Sheet sheet = workbook.getSheetAt(0);
		    Iterator<Row> rows = sheet.iterator();
			
		    int rowNumber = 0;
    		while (rows.hasNext()) {
    			Row currentRow = rows.next();
    			
    			// skip header
    			if(rowNumber < 5) {
    				rowNumber++;
    				continue;
    			}
    			
    			Iterator<Cell> cellsInRow = currentRow.iterator();
    			
    			int cellIndex = 0;
    			while (cellsInRow.hasNext()) {
    				Cell currentCell = cellsInRow.next();
    				
    				if(cellIndex==1) { // Date
    					String date=currentCell.getStringCellValue();
    					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/d/yyyy HH:mm:ss");
    					//convert String to LocalDate
    					 LocalDate localDate = LocalDate.parse(date, formatter);
    					  
    					 dateCount.put(localDate, dateCount.get(localDate) == null ? 1 : dateCount.get(localDate) + 1);
    					 
     					System.out.println(localDate);

    				}else if(cellIndex==8) {
    					String stage=currentCell.getStringCellValue();
    					stageCount.put(stage, stageCount.get(stage) == null ? 1 : stageCount.get(stage) + 1);
    				}else if(cellIndex==1) {
    					
    				}else if(cellIndex==1) {
    					
    				}
    				
    				cellIndex++;
    			}
    		}	
			
    		
    		dateCount.entrySet().forEach(entry->{
    			System.out.println(entry.getKey() + " " + entry.getValue());
    		});
    		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public List<jsonObject> getValues() {
		// TODO Auto-generated method stub
		List<jsonObject> list=new ArrayList();
		dateCount.forEach((k,v)->{
			list.add(new jsonObject(k,v));
		});
		return list;
	}

	public List<stageObject> getStageValues() {
		List<stageObject> list=new ArrayList();
		stageCount.forEach((k,v)->{
			list.add(new stageObject(k,v));
		});
		return list;
	}

}
