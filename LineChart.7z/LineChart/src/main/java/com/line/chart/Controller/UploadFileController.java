package com.line.chart.Controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.line.chart.model.Data;
import com.line.chart.model.jsonObject;
import com.line.chart.model.stageObject;
import com.line.chart.services.FileService;

@Controller
public class UploadFileController {
	
	@Autowired
	private FileService fileService;
	
	@GetMapping("/")
    public String index() {
        return "uploadform";
    }

	@PostMapping("/")
	public String uploadMultipartFile(@RequestParam("uploadfile") MultipartFile file,ModelMap modelMap) {
	
		this.fileService.process(file);
		
		return "Graph";
	}
	
	
	@GetMapping("/jsonValues")
	@ResponseBody
	public List<jsonObject> datas(){
		//Map dateCount=this.fileService.getValues();
		
		return this.fileService.getValues();
		
	}
	
	@GetMapping("/stageValues")
	@ResponseBody
	public List<stageObject> stage(){
		//Map dateCount=this.fileService.getValues();
		
		return this.fileService.getStageValues();
		
	}
	
}
