package com.line.chart.model;

public class stageObject {
	
	private String Stage;
	private int count;
	
	public stageObject() {
		super();
	}
	public stageObject(String stage, int count) {
		super();
		Stage = stage;
		this.count = count;
	}
	public String getStage() {
		return Stage;
	}
	public void setStage(String stage) {
		Stage = stage;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
	

}
