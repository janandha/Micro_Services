package com.line.chart.utils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class ExcelUtil {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate today = LocalDate.now();   
		
		System.out.println(today);
		
		
		String date = "07/14/2021 10:01:50";
		
		 DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/d/yyyy HH:mm:ss");

		  //convert String to LocalDate
		  LocalDate localDate = LocalDate.parse(date, formatter);
		System.out.println(localDate);
		
		
	}

}
