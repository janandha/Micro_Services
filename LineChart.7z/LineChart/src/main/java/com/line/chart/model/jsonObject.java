package com.line.chart.model;

import java.time.LocalDate;

public class jsonObject {

	private LocalDate Date;
	private int numberOfReq;
	
	public jsonObject(LocalDate date, int numberOfReq) {
		super();
		Date = date;
		this.numberOfReq = numberOfReq;
	}
	
	public jsonObject() {
		super();
	}

	public LocalDate getDate() {
		return Date;
	}

	public void setDate(LocalDate date) {
		Date = date;
	}

	public int getNumberOfReq() {
		return numberOfReq;
	}

	public void setNumberOfReq(int numberOfReq) {
		this.numberOfReq = numberOfReq;
	}
	
	
	
	
}
