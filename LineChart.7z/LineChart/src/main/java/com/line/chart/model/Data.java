package com.line.chart.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Data {

	private int numberOfRequest;
	private String Date;
	
	public Data() {
		super();
	}

	public Data(int numberOfRequest, String date) {
		super();
		this.numberOfRequest = numberOfRequest;
		Date = date;
	}

	public int getNumberOfRequest() {
		return numberOfRequest;
	}

	public void setNumberOfRequest(int numberOfRequest) {
		this.numberOfRequest = numberOfRequest;
	}

	public String getDate() {
		return Date;
	}

	public void setDate(String date) {
		Date = date;
	}
	
	
	
}
